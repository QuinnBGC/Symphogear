DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voice_actor` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB ;


DROP TABLE IF EXISTS `songs`;
CREATE TABLE `songs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `song_title` varchar(255) NOT NULL,
  `song_length` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `song_title` (`song_title`)
) ENGINE=InnoDB;


DROP TABLE IF EXISTS `episodes`;
CREATE TABLE `episodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `e_title` varchar(255) NOT NULL,
  `e_length` int(11) NOT NULL,
  `se_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `e_title` (`e_title`),
  CONSTRAINT `ep_se_id` FOREIGN KEY (`se_id`) REFERENCES `season` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB;



DROP TABLE IF EXISTS `seasons`;
CREATE TABLE `seasons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `se_title` varchar(255) NOT NULL,
  `se_length` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `se_title` (`se_title`),
) ENGINE=InnoDB ;


LOCK TABLES `characters` WRITE;
INSERT INTO `characters` VALUES (1,'character1'),(2,'character2'),(3,'character3'),(4,'character4');
UNLOCK TABLES;

LOCK TABLES `songs` WRITE;
INSERT INTO `songs` VALUES (1,'song1', 60),(2,'song2', 65),(3,'song3', 32),(4,'song4', 24);
UNLOCK TABLES;

LOCK TABLES `seasons` WRITE;
INSERT INTO `seasons` VALUES (1,'season1', 12, '11-5-2015', '12-23-2015'),(2,'season2', 10, '7-12-2016', '9-20-2016'),(3,'season3', 11, '11-5-2017', '12-23-2017'),(4,'season4', 8, '7-12-2018', '9-20-2018');
UNLOCK TABLES;

LOCK TABLES `episodes` WRITE;
INSERT INTO `episodes` VALUES (1,'episode1', 60, 4),(2,'episode2', 65, 3),(3,'episode3', 32, 2),(4,'episode4', 24, 1);
UNLOCK TABLES;