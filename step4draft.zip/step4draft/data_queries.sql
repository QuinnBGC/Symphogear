INSERT INTO characters (voice_actor) VALUES (:CharacterNameInput);

SELECT * FROM characters;

INSERT INTO songs (song_title, song_length) VALUES (:SongTitleInput, SongLengthInput);

SELECT * FROM songs;


SELECT * FROM seasons;

SELECT * FROM episodes;
